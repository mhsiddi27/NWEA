/// <reference types="cypress" />

describe('Instagram user', ()=> {

    it('Should be able to navigate to Instagram', ()=>{

        cy.visit('https://www.instagram.com');
        cy.contains('Instagram').should('be.visible');
        
    });

    it('Should be able to log user out', ()=>{

        cy.visit('https://www.instagram.com');

        // if we are logged out
        if(cy.contains('Forgot password?')){

            cy.get('input[name="username"]').should('be.visible');
            cy.get('input[name="password"]').should('be.visible');
            cy.get('button[type="submit"]').should('be.disabled');

        }

        // if logged in
        else{
            cy.get('img[alt~"profile picture"]').click();
            cy.contains('Log Out').click();
            cy.get('input[aria-label~"Phone Number"]').should('be.visible');

            cy.get('input[name="username"]').should('be.visible');
            cy.get('input[name="password"]').should('be.visible');
            cy.get('button[type="submit"]').should('be.disabled');
        }
        
    });

})