/// <reference types="cypress" />

describe('Flatten it!', ()=>{

    it('Should flatten array of integers', ()=>{
        let arr = [1, 2, [3, 4, 5]];
        const flat = flattenArray(arr);

        for(let i = 0; i<= flat.length; i++){
        cy.log(flat[i]);
        }
    })
})


function flattenArray(arr){
    return arr.flat();
}